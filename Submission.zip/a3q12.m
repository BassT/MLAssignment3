function [ result ] = a3q12( dataset )

load('parameters.mat');

result = zeros(size(dataset,1),1);

% project training data onto pc-hyperplane
hyper_face = dataset * coeff_face;
hyper_non_face = dataset * coeff_non_face;

for i = 1:size(dataset, 1) % loop through each training sample - cross-validation
    
    result(i) = bayesianClassifyEx11(dataset(i,:)', prior_face, prior_non_face, ...
        covar_face, covar_non_face, means, coeff_face, coeff_non_face);
    
end

end

function [ class ] = bayesianClassifyEx11( x, prior_face, prior_non_face, covar_face, covar_non_face, means, coeff_face, coeff_non_face )
%bayesianClassify Outputs 1 if face, outputs -1 if non-face
%   NOT TESTED - BassT (2.12.2013)

likelihood_face = computeLikelihoodEx11(x, covar_face, means(1,:), prior_face, coeff_face);
likelihood_non_face = computeLikelihoodEx11(x, covar_non_face, means(2,:), prior_non_face, coeff_non_face);

if likelihood_face > likelihood_non_face 
    class = 1;
elseif likelihood_face < likelihood_non_face
    class = -1;
else
    class = 0;
end

end

function [ likelihood ] = computeLikelihoodEx11( x, covariance, means, prior, coeff )
%computeLikelihood Compute the likelihood using the logarithmic
%discriminnant function
%   Assumes x being a row vector
%   NOT TESTED - BassT (02.12.2013)

hyper = (x' * coeff)';

likelihood = -1/2 * (hyper - means')' * inv(covariance) * (hyper - means') + ...
    log(prior) + (-361/2 * log(2*pi) - 1/2 * log(det(covariance)));

end

